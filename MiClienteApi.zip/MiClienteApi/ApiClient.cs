﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using WebPuertoRico.Models;
using System.Net.Http.Json; // Asegúrate de importar esta referencia

namespace MiClienteApi
{
    public class ApiClient
    {
        private readonly HttpClient _httpClient;

        public ApiClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
            _httpClient.BaseAddress = new Uri("https://localhost:44345/api/"); // Reemplaza con la URL de tu API
        }

        public async Task<IEnumerable<Tripulante>> GetTripulantesAsync()
        {
            var response = await _httpClient.GetAsync("Tripulantes");

            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<IEnumerable<Tripulante>>();
            }
            else
            {
                throw new Exception("Error al obtener tripulantes: " + response.ReasonPhrase);
            }
        }

        public async Task<Tripulante> CreateTripulanteAsync(Tripulante tripulante)
        {
            var response = await _httpClient.PostAsJsonAsync("Tripulantes", tripulante);

            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<Tripulante>();
            }
            else
            {
                throw new Exception("Error al crear tripulante: " + response.ReasonPhrase);
            }
        }
    }
}
