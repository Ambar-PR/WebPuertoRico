﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;

namespace MiClienteApi
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // Configurar servicios
            var services = new ServiceCollection();
            services.AddScoped<HttpClient>(); // Registrar HttpClient
            services.AddScoped<ApiClient>();

            var serviceProvider = services.BuildServiceProvider();

            // Obtener HttpClient del contenedor de servicios
            var httpClient = serviceProvider.GetRequiredService<HttpClient>();
            httpClient.BaseAddress = new Uri("https://localhost:44345/api/"); // Reemplazar con tu URL base

            var apiClient = new ApiClient(httpClient);

            try
            {
                var tripulantes = await apiClient.GetTripulantesAsync();
                foreach (var tripulante in tripulantes)
                {
                    Console.WriteLine($"{tripulante.Nombres} {tripulante.Apellidos}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }
}
