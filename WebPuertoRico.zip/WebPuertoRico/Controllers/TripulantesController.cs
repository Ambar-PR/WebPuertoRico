﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using WebPuertoRico.Models;
using WebPuertoRico.Services; // Asegúrate de ajustar el namespace según la ubicación de TripulantesService

namespace WebPuertoRico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TripulantesController : ControllerBase
    {
        private readonly TripulantesService _tripulantesService;

        public TripulantesController(TripulantesService tripulantesService)
        {
            _tripulantesService = tripulantesService;
        }

        // GET: api/Tripulantes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Tripulante>>> GetTripulantes()
        {
            var tripulantes = await _tripulantesService.GetTripulantesAsync();
            return Ok(tripulantes);
        }

        // GET: api/Tripulantes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Tripulante>> GetTripulante(int id)
        {
            var tripulante = await _tripulantesService.GetTripulanteByIdAsync(id);

            if (tripulante == null)
            {
                return NotFound();
            }

            return tripulante;
        }

        // POST: api/Tripulantes
        [HttpPost]
        public async Task<ActionResult<Tripulante>> PostTripulante(Tripulante tripulante)
        {
            var newTripulante = await _tripulantesService.CreateTripulanteAsync(tripulante);
            return CreatedAtAction(nameof(GetTripulante), new { id = newTripulante.Id }, newTripulante);
        }

        // PUT: api/Tripulantes/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTripulante(int id, Tripulante tripulante)
        {
            try
            {
                await _tripulantesService.UpdateTripulanteAsync(id, tripulante);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }

            return NoContent();
        }

        // DELETE: api/Tripulantes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTripulante(int id)
        {
            try
            {
                await _tripulantesService.DeleteTripulanteAsync(id);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }

            return NoContent();
        }
    }
}
