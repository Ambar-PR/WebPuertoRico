﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebPuertoRico.Data;
using WebPuertoRico.Models;

namespace WebPuertoRico.Services
{
    public class TripulantesService
    {
        private readonly ApplicationDbContext _context;

        public TripulantesService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<Tripulante>> GetTripulantesAsync()
        {
            return await _context.Tripulantes.ToListAsync();
        }

        public async Task<Tripulante> GetTripulanteByIdAsync(int id)
        {
            return await _context.Tripulantes.FindAsync(id);
        }

        public async Task<Tripulante> CreateTripulanteAsync(Tripulante tripulante)
        {
            _context.Tripulantes.Add(tripulante);
            await _context.SaveChangesAsync();
            return tripulante;
        }

        public async Task UpdateTripulanteAsync(int id, Tripulante tripulante)
        {
            if (id != tripulante.Id)
            {
                throw new ArgumentException("Id del tripulante no coincide con el id proporcionado");
            }

            _context.Entry(tripulante).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TripulanteExists(id))
                {
                    throw new Exception("Tripulante no encontrado");
                }
                else
                {
                    throw;
                }
            }
        }

        public async Task DeleteTripulanteAsync(int id)
        {
            var tripulante = await _context.Tripulantes.FindAsync(id);
            if (tripulante == null)
            {
                throw new Exception("Tripulante no encontrado");
            }

            _context.Tripulantes.Remove(tripulante);
            await _context.SaveChangesAsync();
        }

        private bool TripulanteExists(int id)
        {
            return _context.Tripulantes.Any(e => e.Id == id);
        }
    }
}
