﻿namespace WebPuertoRico.Models
{
    public class Tripulante
    {
        public int Id { get; set; }
        public string TipoDocumento { get; set; }
        public string Documento { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string Sexo { get; set; }
        public string Foto { get; set; }
        public string Estado { get; set; }
        public decimal Monto { get; set; }
    }

}
