﻿using Microsoft.EntityFrameworkCore;
using WebPuertoRico.Models;

namespace WebPuertoRico.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Tripulante> Tripulantes { get; set; }
    }
}